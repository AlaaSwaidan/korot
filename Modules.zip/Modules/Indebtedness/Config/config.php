<?php

return [
    'name' => 'Indebtedness'
];
