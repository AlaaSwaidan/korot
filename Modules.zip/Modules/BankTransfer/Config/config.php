<?php

return [
    'name' => 'BankTransfer'
];
