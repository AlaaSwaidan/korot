<?php

return [
    'name' => 'Company'
];
