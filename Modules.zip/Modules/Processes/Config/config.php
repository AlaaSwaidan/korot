<?php

return [
    'name' => 'Processes'
];
