<?php

return [
    'name' => 'Merchant'
];
