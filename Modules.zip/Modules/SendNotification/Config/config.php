<?php

return [
    'name' => 'SendNotification'
];
