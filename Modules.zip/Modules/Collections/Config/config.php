<?php

return [
    'name' => 'Collections'
];
