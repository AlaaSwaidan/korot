<?php

return [
    'name' => 'Distributor'
];
