<?php

return [
    'name' => 'SuperAdmin'
];
